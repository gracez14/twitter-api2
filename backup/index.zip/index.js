import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Square(props) {
  return (
    <button className="square" onClick={props.onClick}>
      {props.value}
    </button>
  );
}

class Menu extends React.Component {
  constructor() {
    super();
    this.state = {
      squares: Array(4).fill(null),
    };
  }

  subMenu(i) {
    //const subMenu1 = this.render.squares;
    //square[i] = 'Twitter Search';
    
  }

  renderSquare(i) {
    return (
      <Square
        value="Sources"
        onClick={() => this.subMenu(i)}
      />
    );
  }

  render() {
    const status = 'Twitter API Menu';
    const pipe = 'Pipelines ';
    const data = "Datasets";
    const dash = "Dashboards";
          
    return (
      <div>
        <div className="status">{status}</div>
        <div className="square">
          {this.renderSquare(0)}

        </div>
        
        <div className="square">
          {pipe}

        </div>
        <div className="square">
          {data}

        </div>
         <div className="square">
          {dash}

        </div>
      </div>
    );
  }
}

class API extends React.Component {
  render() {
    return (
       <div>  
      <Menu />
        </div>

    );
  }
}

// ========================================

ReactDOM.render(
  <API />,
  document.getElementById('root')
);
