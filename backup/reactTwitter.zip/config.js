// config.js 
// store the config info for npm twitter

module.exports = {
  consumer_key: 'RuJpmlRpXja21rVk7LlA0qZ9f',
  consumer_secret: 'vKz3e4VWAyiWfASi9aeENLXhH3jyuveff5Sev8eNFRr6hUlPef',
  access_token_key: '2853794314-kKoq6f5t9E2kLRzFWwcrUB68dLwnelPPoM4NC0q',
  access_token_secret: 'llO5nWx7QdO2XlUyeBUe6KPZeL5y9MqlZqTu5sRXvNZbZ'
}